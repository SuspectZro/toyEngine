function runState(id)
	-- body
		state = GetState(id).state
		--State that need a counter------------
		if( state == "Walking" or state == "Idle" or state == "Punch" or state == "Crouching")
		then	
			
			if (state == "Walking" )
			then
				print(GetState(id).counter)
				print(GetState(id).state)
				GetSprite(id).name = "rWalk"
				GetState(id).counter = GetState(id).counter - 1
			end
			if(state == "Punch")
			then
				print(GetState(id).counter)
				print(GetState(id).state)
				GetSprite(id).name = "p1p"
				GetState(id).counter = GetState(id).counter - 1
			end
			if(state == "Crouching")
			then
				--print(GetState(id).counter)
				GetSprite(id).name = "rCrouch"
				GetState(id).counter = GetState(id).counter - 1
				if(GetState(id).counter == 0)
				then
					GetState(id).state = "Idle"
				end

			end
			if(GetState(id).counter < 8 and state ~= "Crouching")
			then
				print(state)
				GetState(id).state = "Idle"
				GetSprite(id).name = "player1"
				if(GetState(id).counter > 0)
				then
				GetState(id).counter = GetState(id).counter - 1
				end
			end
		end
		-----state without counter--------------------
		
		if(state == "Jumping")
		then
			GetSprite(id).name = "rJ"
			if(GetPosition(id).py < -27)
			then
				GetState(id).state = "Idle"
				GetState(id).counter = 1
				--GetSprite(id).name = "player1"
			end
		end
		
end

local id = ...

runState(id)

--Punch------------------------
if(KeyIsDown(KEYBOARD.E))
then
	if(GetState(id).counter == 0)
	then
		GetState(id).state = "Punch"
		GetState(id).counter = 20
	end
end

if( GetState(id).state ~= "Jumping")
then


GetVelocity(id).vx = 0.0
-----walk back and forth -----------------
if(KeyIsDown(KEYBOARD.A)  and GetState(id).state ~= "Crouching" and GetState(id).state ~= "Punch")
then
	if(GetState(id).counter == 0)
	then
		GetState(id).state = "Walking"
		GetState(id).counter = 20		
	end
	GetVelocity(id).vx = GetVelocity(id).vx - 1.5
end

if(KeyIsDown(KEYBOARD.D) and GetState(id).state ~= "Punch" and GetState(id).state ~= "Crouching")
then
	if(GetState(id).counter == 0 and GetPosition(id).py < -26 )
	then
		GetState(id).state = "Walking"
		GetState(id).counter = 20		
	end
	GetVelocity(id).vx = GetVelocity(id).vx + 1.5
end

--Crouching--------------------
if(KeyIsDown(KEYBOARD.S))
then
	GetState(id).state = "Crouching"
	GetState(id).counter = 2
		
end

--Jumping------------------------
if(KeyIsDown(KEYBOARD.W))
then
		GetState(id).state = "Jumping"
	GetVelocity(id).vy = GetVelocity(id).vy + 2
end

end
--Ground----------------
if(GetPosition(id).py < -30)
then
	GetVelocity(id).vy = 0
	GetPosition(id).py = -29.9
end

